"""
FinVista Capital – Financial Intelligence Assistant
Streamlit UI  |  RAG-powered  |  Gemini LLM
"""

import os
import tempfile
import logging

import streamlit as st

from rag_engine import (
    index_document,
    generate_response,
    get_collection_stats,
    delete_document,
)

logger = logging.getLogger(__name__)

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="FinVista Capital – Financial Intelligence Assistant",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Session state init ─────────────────────────────────────────────────────────
if "conversation_history" not in st.session_state:
    st.session_state.conversation_history = []
if "processed_files" not in st.session_state:
    st.session_state.processed_files = set()


# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #1a3c5e 0%, #2d6a9f 100%);
        padding: 1.5rem 2rem;
        border-radius: 12px;
        color: white;
        margin-bottom: 1.5rem;
    }
    .chat-user {
        background: #e8f4f8;
        border-left: 4px solid #2d6a9f;
        padding: 0.75rem 1rem;
        border-radius: 0 8px 8px 0;
        margin: 0.5rem 0;
    }
    .chat-assistant {
        background: #f0f7f0;
        border-left: 4px solid #27ae60;
        padding: 0.75rem 1rem;
        border-radius: 0 8px 8px 0;
        margin: 0.5rem 0;
    }
    .citation-box {
        background: #fff3cd;
        border: 1px solid #ffc107;
        border-radius: 8px;
        padding: 0.5rem 0.75rem;
        font-size: 0.85rem;
        margin-top: 0.5rem;
    }
    .stat-card {
        background: white;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
</style>
""", unsafe_allow_html=True)

# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>📊 FinVista Capital</h1>
    <p style="margin:0; opacity:0.85">Enterprise Financial Intelligence Assistant · Powered by RAG + Gemini</p>
</div>
""", unsafe_allow_html=True)


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Configuration")

    api_key = st.text_input(
        "Gemini API Key",
        value=os.getenv("GEMINI_API_KEY", ""),
        type="password",
        help="Get your key at https://aistudio.google.com",
    )
    if api_key:
        os.environ["GEMINI_API_KEY"] = api_key
        import google.generativeai as genai
        genai.configure(api_key=api_key)

    st.divider()

    # ── Document Upload ────────────────────────────────────────────────────────
    st.header("📁 Document Upload")
    uploaded_files = st.file_uploader(
        "Upload PDF documents",
        type=["pdf"],
        accept_multiple_files=True,
        help="Supports annual reports, research notes, compliance manuals, etc.",
    )

    if uploaded_files and api_key:
        for uf in uploaded_files:
            if uf.name not in st.session_state.processed_files:
                with st.spinner(f"Processing {uf.name}…"):
                    try:
                        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                            tmp.write(uf.read())
                            tmp_path = tmp.name
                        n_chunks = index_document(tmp_path)
                        st.session_state.processed_files.add(uf.name)
                        st.success(f"✅ {uf.name} — {n_chunks} chunks indexed")
                        os.unlink(tmp_path)
                    except Exception as exc:
                        st.error(f"❌ Error processing {uf.name}: {exc}")
    elif uploaded_files and not api_key:
        st.warning("⚠️ Enter your Gemini API key first.")

    st.divider()

    # ── Knowledge Base Stats ───────────────────────────────────────────────────
    st.header("🗄️ Knowledge Base")
    if st.button("🔄 Refresh Stats"):
        st.rerun()

    stats = get_collection_stats()
    col1, col2 = st.columns(2)
    col1.metric("Documents", stats["document_count"])
    col2.metric("Chunks",    stats["total_chunks"])

    if stats["documents"]:
        st.subheader("Indexed Documents")
        for doc in stats["documents"]:
            c1, c2 = st.columns([3, 1])
            c1.write(f"📄 {doc}")
            if c2.button("🗑️", key=f"del_{doc}", help=f"Remove {doc}"):
                if delete_document(doc):
                    st.success(f"Removed {doc}")
                    st.session_state.processed_files.discard(doc)
                    st.rerun()

    st.divider()

    # ── Conversation controls ──────────────────────────────────────────────────
    st.header("💬 Conversation")
    if st.button("🗑️ Clear History", use_container_width=True):
        st.session_state.conversation_history = []
        st.rerun()

    st.caption(f"Turns: {len(st.session_state.conversation_history)}")


# ── Main Content ───────────────────────────────────────────────────────────────
tab_chat, tab_history, tab_help = st.tabs(["💬 Chat", "📜 History", "❓ Help"])

# ── Chat Tab ───────────────────────────────────────────────────────────────────
with tab_chat:
    if not api_key:
        st.info("👈 Enter your Gemini API key in the sidebar to get started.")
    elif stats["total_chunks"] == 0:
        st.info("👈 Upload and index at least one PDF document to begin querying.")
    else:
        # Show last 5 turns
        if st.session_state.conversation_history:
            st.subheader("Recent Conversation")
            for turn in st.session_state.conversation_history[-5:]:
                st.markdown(f'<div class="chat-user">🧑 {turn["user"]}</div>', unsafe_allow_html=True)
                st.markdown(f'<div class="chat-assistant">🤖 {turn["assistant"]}</div>', unsafe_allow_html=True)
                if turn.get("citations"):
                    with st.expander("📎 Sources"):
                        for c in turn["citations"]:
                            st.markdown(
                                f'<div class="citation-box">📄 <b>{c["source"]}</b> '
                                f'— Page {c["page"]} &nbsp; (similarity: {c["similarity"]:.2%})</div>',
                                unsafe_allow_html=True,
                            )
        st.divider()

        # Sample questions
        st.subheader("Ask a Question")
        sample_qs = [
            "What are the key risk factors mentioned in the documents?",
            "Summarise the investment guidelines.",
            "What compliance requirements are highlighted?",
            "What are the main financial performance indicators?",
        ]
        cols = st.columns(2)
        for i, q in enumerate(sample_qs):
            if cols[i % 2].button(q, key=f"sample_{i}", use_container_width=True):
                st.session_state["prefilled_query"] = q

        query = st.text_area(
            "Your question",
            value=st.session_state.pop("prefilled_query", ""),
            height=100,
            placeholder="e.g. What are the key investment risks mentioned in the annual report?",
        )

        c1, c2 = st.columns([1, 5])
        submit = c1.button("🚀 Ask", type="primary", use_container_width=True)
        c2.caption("Responses are grounded in your uploaded documents.")

        if submit and query.strip():
            with st.spinner("Searching knowledge base and generating response…"):
                try:
                    answer, citations = generate_response(
                        query.strip(), st.session_state.conversation_history
                    )
                    st.session_state.conversation_history.append({
                        "user":      query.strip(),
                        "assistant": answer,
                        "citations": citations,
                    })
                    st.rerun()
                except Exception as exc:
                    logger.error("Query error: %s", exc)
                    st.error(f"Error generating response: {exc}")


# ── History Tab ────────────────────────────────────────────────────────────────
with tab_history:
    st.subheader("Full Conversation History")
    if not st.session_state.conversation_history:
        st.info("No conversation history yet.")
    else:
        for i, turn in enumerate(st.session_state.conversation_history, 1):
            with st.expander(f"Turn {i}: {turn['user'][:80]}…"):
                st.markdown(f"**Question:** {turn['user']}")
                st.markdown(f"**Answer:**\n\n{turn['assistant']}")
                if turn.get("citations"):
                    st.markdown("**Sources:**")
                    for c in turn["citations"]:
                        st.markdown(f"- `{c['source']}` · Page {c['page']} · similarity {c['similarity']:.2%}")


# ── Help Tab ───────────────────────────────────────────────────────────────────
with tab_help:
    st.subheader("How to Use FinVista Financial Intelligence Assistant")
    st.markdown("""
### Quick Start
1. **Enter your Gemini API key** in the sidebar (get one free at [Google AI Studio](https://aistudio.google.com))
2. **Upload PDF documents** — annual reports, research notes, compliance manuals, etc.
3. **Wait for indexing** — documents are chunked, embedded, and stored in the vector database
4. **Ask questions** in natural language in the Chat tab

### How It Works (RAG Pipeline)
```
PDF Upload → Text Extraction → Chunking → Embeddings → Vector DB (ChromaDB)
                                                              ↓
User Query → Query Embedding → Semantic Search → Top-K Chunks
                                                              ↓
                                              Prompt + Context → Gemini LLM → Answer + Citations
```

### Tips
- Upload multiple documents to cross-reference information
- Ask specific questions for better results
- Citations show which document and page number the answer came from
- Use the conversation history for multi-turn analysis

### Supported Document Types
- Annual Reports & Financial Statements
- Analyst Research Reports
- Compliance & Regulatory Manuals
- Investment Policy Documents
- Market Intelligence Reports
""")
