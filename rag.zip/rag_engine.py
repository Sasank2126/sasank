"""
RAG Engine — FinVista Capital Financial Intelligence Assistant
Gemini API (LLM + Embeddings) · ChromaDB (Vector Store) · PyMuPDF (PDF Parser)
"""

import os
import logging
import hashlib
from pathlib import Path
from typing import List, Dict, Tuple

import fitz                          # PyMuPDF
import chromadb
from chromadb.config import Settings
import google.generativeai as genai
from langchain_text_splitters import RecursiveCharacterTextSplitter   # FIX: correct package

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── Config ─────────────────────────────────────────────────────────────────────
CHROMA_DB_PATH  = os.getenv("CHROMA_DB_PATH", "./chroma_db")
COLLECTION_NAME = "finvista_docs"
EMBED_MODEL     = "models/embedding-001"
CHAT_MODEL      = "gemini-1.5-flash"
CHUNK_SIZE      = 1000
CHUNK_OVERLAP   = 200
TOP_K_RESULTS   = 5

# ── FIX: lazy API key — never configure at import time ─────────────────────────
def _configure_gemini() -> None:
    """Read key from env and configure Gemini. Called before every API call."""
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key:
        raise ValueError(
            "GEMINI_API_KEY is not set. "
            "Enter it in the sidebar or set the environment variable."
        )
    genai.configure(api_key=key)


# ── ChromaDB ───────────────────────────────────────────────────────────────────
def _get_client() -> chromadb.Client:
    return chromadb.PersistentClient(
        path=CHROMA_DB_PATH,
        settings=Settings(anonymized_telemetry=False),
    )


def _get_collection(client: chromadb.Client) -> chromadb.Collection:
    return client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )


# ── PDF Parsing ────────────────────────────────────────────────────────────────
def parse_pdf(file_path: str) -> List[Dict]:
    pages = []
    doc   = fitz.open(file_path)
    for page_num, page in enumerate(doc, start=1):
        text = page.get_text("text").strip()
        if text:
            pages.append({
                "page":   page_num,
                "text":   text,
                "source": Path(file_path).name,
            })
    logger.info("Parsed %d pages from %s", len(pages), file_path)
    return pages


# ── Chunking ───────────────────────────────────────────────────────────────────
def chunk_pages(pages: List[Dict]) -> List[Dict]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ".", " "],
    )
    chunks = []
    for page in pages:
        for i, split in enumerate(splitter.split_text(page["text"])):
            chunks.append({
                "text":   split,
                "source": page["source"],
                "page":   page["page"],
                "chunk":  i,
            })
    logger.info("Created %d chunks", len(chunks))
    return chunks


# ── Embeddings ─────────────────────────────────────────────────────────────────
def _embed_texts(texts: List[str]) -> List[List[float]]:
    _configure_gemini()
    embeddings = []
    for i in range(0, len(texts), 100):
        batch  = texts[i: i + 100]
        result = genai.embed_content(
            model=EMBED_MODEL,
            content=batch,
            task_type="retrieval_document",
        )
        embeddings.extend(result["embedding"])
    return embeddings


# ── Index a document ──────────────────────────────────────────────────────────
def index_document(file_path: str) -> int:
    pages  = parse_pdf(file_path)
    chunks = chunk_pages(pages)
    if not chunks:
        return 0

    texts     = [c["text"]   for c in chunks]
    metadatas = [{"source": c["source"], "page": c["page"], "chunk": c["chunk"]} for c in chunks]
    ids       = [hashlib.md5(f"{c['source']}_{c['page']}_{c['chunk']}".encode()).hexdigest()
                 for c in chunks]
    embeddings = _embed_texts(texts)

    client     = _get_client()
    collection = _get_collection(client)

    for i in range(0, len(chunks), 100):
        collection.upsert(
            ids=ids[i: i + 100],
            embeddings=embeddings[i: i + 100],
            documents=texts[i: i + 100],
            metadatas=metadatas[i: i + 100],
        )
    logger.info("Indexed %d chunks for %s", len(chunks), file_path)
    return len(chunks)


# ── Semantic Search ────────────────────────────────────────────────────────────
def semantic_search(query: str, top_k: int = TOP_K_RESULTS) -> List[Dict]:
    _configure_gemini()
    client     = _get_client()
    collection = _get_collection(client)

    # FIX: guard against empty collection (ChromaDB crashes if n_results > count)
    total = collection.count()
    if total == 0:
        return []

    n = min(top_k, total)

    query_vec = genai.embed_content(
        model=EMBED_MODEL,
        content=query,
        task_type="retrieval_query",
    )["embedding"]

    results = collection.query(
        query_embeddings=[query_vec],
        n_results=n,
        include=["documents", "metadatas", "distances"],
    )

    hits = []
    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        hits.append({
            "text":       doc,
            "source":     meta.get("source", "unknown"),
            "page":       meta.get("page", 0),
            "similarity": round(1 - dist, 4),
        })
    logger.info("Retrieved %d chunks for query", len(hits))
    return hits


# ── Prompt Builder ─────────────────────────────────────────────────────────────
def build_prompt(query: str, context_chunks: List[Dict], history: List[Dict]) -> str:
    context = "\n\n---\n\n".join(
        f"[Source: {c['source']}, Page {c['page']}]\n{c['text']}"
        for c in context_chunks
    )
    history_text = ""
    for turn in history[-6:]:
        history_text += f"User: {turn['user']}\nAssistant: {turn['assistant']}\n\n"

    return (
        "You are FinVista Capital's Financial Intelligence Assistant.\n"
        "Answer questions accurately using ONLY the provided context.\n"
        "If the answer is not in the context, say so clearly.\n"
        "Always cite the source document and page number.\n\n"
        f"CONVERSATION HISTORY:\n{history_text}\n"
        f"CONTEXT FROM DOCUMENTS:\n{context}\n\n"
        f"CURRENT QUESTION: {query}\n\n"
        "Provide a detailed, accurate answer with citations in the format "
        "[Source: filename, Page X]."
    )


# ── Generate Response (full RAG pipeline) ─────────────────────────────────────
def generate_response(query: str, conversation_history: List[Dict]) -> Tuple[str, List[Dict]]:
    _configure_gemini()
    context_chunks = semantic_search(query)
    if not context_chunks:
        return "No relevant documents found. Please upload documents first.", []

    prompt   = build_prompt(query, context_chunks, conversation_history)
    model    = genai.GenerativeModel(CHAT_MODEL)
    response = model.generate_content(prompt)
    answer   = response.text
    logger.info("Generated response (%d chars)", len(answer))
    return answer, context_chunks


# ── Stats ──────────────────────────────────────────────────────────────────────
def get_collection_stats() -> Dict:
    try:
        client     = _get_client()
        collection = _get_collection(client)
        count      = collection.count()
        sources: set = set()
        if count > 0:
            sources = {m.get("source", "unknown")
                       for m in collection.get(include=["metadatas"])["metadatas"]}
        return {"total_chunks": count, "documents": list(sources), "document_count": len(sources)}
    except Exception as exc:
        logger.error("Stats error: %s", exc)
        return {"total_chunks": 0, "documents": [], "document_count": 0}


# ── Delete Document ────────────────────────────────────────────────────────────
def delete_document(source_name: str) -> bool:
    try:
        client     = _get_client()
        collection = _get_collection(client)
        results    = collection.get(where={"source": source_name}, include=["metadatas"])
        ids        = results.get("ids", [])
        if ids:
            collection.delete(ids=ids)
            logger.info("Deleted %d chunks for %s", len(ids), source_name)
            return True
        return False
    except Exception as exc:
        logger.error("Delete error: %s", exc)
        return False
